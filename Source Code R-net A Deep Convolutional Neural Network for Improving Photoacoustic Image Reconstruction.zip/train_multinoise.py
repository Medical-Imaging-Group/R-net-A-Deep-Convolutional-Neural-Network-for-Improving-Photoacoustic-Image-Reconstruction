import sys
sys.path.append("/home/jayasimha/Documents/PAT/")

import fire
import numpy as np
import tensorflow as tf
import numpy as np
import data_multinoise
import timeit
import os
import shutil
import time




np.random.seed(1222)

from tensorflow_fcn import fcn8_vgg
from model_mulitnoise import model

# REC_IMAGE_PATH = "train/patches"
# SEG_IMAGE_PATH = "train/patches/segmentation"

# VALIDATION_REC_IMAGE_PATH = "validation/patches"
# VALIDATION_SEG_IMAGE_PATH = "validation/patches/segmentation"


REC_IMAGE_PATH = "train/no_scale/patches"
SEG_IMAGE_PATH = "train/no_scale/patches/segmentation"

VALIDATION_REC_IMAGE_PATH = "validation/no_scale/patches"
VALIDATION_SEG_IMAGE_PATH = "validation/no_scale/patches/segmentation"


def _tf_fspecial_gauss(size, sigma):
		"""Function to mimic the 'fspecial' gaussian MATLAB function
		"""
		x_data, y_data = np.mgrid[-size//2 + 1:size//2 + 1, -size//2 + 1:size//2 + 1]

		x_data = np.expand_dims(x_data, axis=-1)
		x_data = np.expand_dims(x_data, axis=-1)

		y_data = np.expand_dims(y_data, axis=-1)
		y_data = np.expand_dims(y_data, axis=-1)

		x = tf.constant(x_data, dtype=tf.float32)
		y = tf.constant(y_data, dtype=tf.float32)

		g = tf.exp(-((x**2 + y**2)/(2.0*sigma**2)))
		return g / tf.reduce_sum(g)

def tf_ssim(img1, img2, cs_map=False, mean_metric=True, size=11, sigma=1.5):
		window = _tf_fspecial_gauss(size, sigma) # window shape [size, size]
		K1 = 0.01
		K2 = 0.03
		L = 1  # depth of image (255 in case the image has a differnt scale)
		C1 = (K1*L)**2
		C2 = (K2*L)**2
		mu1 = tf.nn.conv2d(img1, window, strides=[1,1,1,1], padding='VALID')
		mu2 = tf.nn.conv2d(img2, window, strides=[1,1,1,1],padding='VALID')
		mu1_sq = mu1*mu1
		mu2_sq = mu2*mu2
		mu1_mu2 = mu1*mu2
		sigma1_sq = tf.nn.conv2d(img1*img1, window, strides=[1,1,1,1],padding='VALID') - mu1_sq
		sigma2_sq = tf.nn.conv2d(img2*img2, window, strides=[1,1,1,1],padding='VALID') - mu2_sq
		sigma12 = tf.nn.conv2d(img1*img2, window, strides=[1,1,1,1],padding='VALID') - mu1_mu2
		if cs_map:
				value = (((2*mu1_mu2 + C1)*(2*sigma12 + C2))/((mu1_sq + mu2_sq + C1)*
										(sigma1_sq + sigma2_sq + C2)),
								(2.0*sigma12 + C2)/(sigma1_sq + sigma2_sq + C2))
		else:
				value = ((2*mu1_mu2 + C1)*(2*sigma12 + C2))/((mu1_sq + mu2_sq + C1)*
										(sigma1_sq + sigma2_sq + C2))

		if mean_metric:
				value = tf.reduce_mean(value)
		return value

def mse_loss(y_pred, y_true):
	return tf.reduce_mean(tf.losses.mean_squared_error(predictions=y_pred, labels=y_true))

def gradient_loss(ypred, ytrue):
	s = ytrue.get_shape().as_list()
	grad_loss = tf.reduce_mean(
		tf.square(
			tf.abs(tf.slice(ypred, begin=[0, 1, 1, 0], size=[-1, -1, -1, -1]) - tf.slice(ypred, begin = [0, 0, 1, 0], size=[-1, s[1] - 1,- 1, -1]))
			-
			tf.abs(tf.slice(ytrue, begin=[0, 1, 1, 0], size=[-1, -1, -1, -1]) - tf.slice(ytrue, begin = [0, 0, 1, 0], size=[-1, s[1] - 1,- 1, -1]))
		)
		+
		tf.square(
			tf.abs(tf.slice(ypred, begin=[0, 1, 1, 0], size=[-1, -1, -1, -1]) - tf.slice(ypred, begin = [0, 1, 0, 0], size=[-1, - 1, s[2] - 1, -1]))
			-
			tf.abs(tf.slice(ytrue, begin=[0, 1, 1, 0], size=[-1, -1, -1, -1]) - tf.slice(ytrue, begin = [0, 1, 0, 0], size=[-1, - 1, s[2] - 1, -1]))
		)
	)
	return grad_loss

def total_loss(y_pred, y_true, alpha = 0):
	return mse_loss(y_pred, y_true) + alpha * gradient_loss(y_pred, y_true)


def ssim_loss(y_pred, y_true):
	y_pred = tf.expand_dims(tf.unstack(y_pred, num = 2, axis=3)[1], -1)
	y_true = tf.expand_dims(tf.unstack(y_true, num = 2, axis=3)[1], -1)
	return tf_ssim(y_pred, y_true)


def log_loss(logits, labels, num_classes, head=None):
		"""Calculate the loss from the logits and the labels.
		Args:
			logits: tensor, float - [batch_size, width, height, num_classes].
					Use vgg_fcn.up as logits.
			labels: Labels tensor, int32 - [batch_size, width, height, num_classes].
					The ground truth of your data.
			head: numpy array - [num_classes]
					Weighting the loss of each class
					Optional: Prioritize some classes
		Returns:
			loss: Loss tensor of type float.
		"""
		with tf.name_scope('loss'):
				logits = tf.reshape(logits, (-1, num_classes))
				epsilon = tf.constant(value=1e-4)
				logits = logits
				labels = tf.to_float(tf.reshape(labels, (-1, num_classes)))

				softmax = tf.nn.softmax(logits) + epsilon

				if head is not None:
						cross_entropy = -tf.reduce_sum(tf.multiply(labels * tf.log(softmax),
																					 head), reduction_indices=[1])
				else:
						cross_entropy = -tf.reduce_sum(
								labels * tf.log(softmax), reduction_indices=[1])

				cross_entropy_mean = tf.reduce_mean(cross_entropy,
																						name='xentropy_mean')
				tf.add_to_collection('losses', cross_entropy_mean)

				loss = tf.add_n(tf.get_collection('losses'), name='total_loss')
		return loss




class Trainer(object):
	"""docstring for Train"""
	def __init__(self, clean = False):
		self.train_mode = tf.placeholder(tf.bool)
		if clean:
			if os.path.isdir('LOG'):
				shutil.rmtree('LOG')
			os.mkdir('LOG')
			os.mkdir('LOG/train')
			os.mkdir('LOG/test')
			if os.path.isdir('checkpoint'):
				shutil.rmtree('checkpoint')
			os.mkdir('checkpoint')

	def train(self, num_steps = 1000, learning_rate=1e-3, ckpt_interval = 1000, model_path=None):
		import os
		os.environ["CUDA_DEVICE_ORDER"]="PCI_BUS_ID"   # see issue #152
		os.environ["CUDA_VISIBLE_DEVICES"]="0"
		config = tf.ConfigProto(gpu_options=tf.GPUOptions(per_process_gpu_memory_fraction=0.6))
		sensor_points = [12020, 12040, 12060]
		batch_size = 32
		alpha = 0.1
		img_height, img_width = 96, 96
		# config = tf.ConfigProto()
		# config.gpu_options.allow_growth = True
		with tf.Session(config=config) as sess:
			train_writer = tf.summary.FileWriter('LOG/train', graph=sess.graph)
			test_writer = tf.summary.FileWriter('LOG/test', graph=sess.graph)
			train_data = data_multinoise.Dataset(REC_IMAGE_PATH, SEG_IMAGE_PATH, sensor_points, batch_size = batch_size, image_size=(img_height, img_width))
			validation_data = data_multinoise.Dataset(VALIDATION_REC_IMAGE_PATH, VALIDATION_SEG_IMAGE_PATH, sensor_points, batch_size = batch_size, image_size=(img_height, img_width))

			t_coord  = tf.train.Coordinator()
			t_threads = tf.train.start_queue_runners(coord=t_coord)


			X = tf.placeholder(tf.float32, [None, img_height, img_width, 1])
			Y = tf.placeholder(tf.float32, [None, img_height, img_width, 1])

			global_step = tf.Variable(0, trainable=False)
			rate = tf.train.exponential_decay(learning_rate, global_step, 1000, 0.5, staircase=True)
			optimizer = tf.train.AdamOptimizer(rate)

			cnn = model(sess, optimizer=optimizer, batch_size = batch_size, tot_res_blocks=8)
			phase_train = tf.placeholder(tf.bool, [], name='is_training')

			pred = cnn.inference(X, phase_train)
			loss = total_loss(pred, Y, 1)
			train_op = cnn.backprop(loss, global_step)

			tf.summary.image('Input Image', X, collections= ['validation'])
			tf.summary.image('Gnd Truth', Y, collections= ['validation'])
			tf.summary.image('Predicted Image', pred, collections= ['validation'])
			tf.summary.scalar("Loss", loss, collections= ['train'])
			tf.summary.scalar("Learning Rate", rate, collections=['train'])
			train_summary_op = tf.summary.merge_all('train')
			validation_summary_op = tf.summary.merge_all('validation')
		

			self.saver = tf.train.Saver(max_to_keep = 5)
			if model_path is None:
				init = tf.global_variables_initializer()
				sess.run(init)
			else:
				print ("Restoring Saved Model")
				model_saver = tf.train.Saver()
				model_saver.restore(sess, model_path)


			step = 0
			while step <= num_steps:
				start = time.time()
				X_train_batch, Y_train_batch = train_data.get_input_tensors()
				_ = sess.run([train_op], feed_dict={X: X_train_batch, Y:Y_train_batch, phase_train:True})
				if step % 100 == 0:
					summary = sess.run(train_summary_op, feed_dict={X: X_train_batch, Y:Y_train_batch, phase_train:True})
					train_writer.add_summary(summary, step)
				if step % ckpt_interval == 0:
					self.saver.save(sess, 'checkpoint/fcn-net', global_step=step)
					X_validation_batch, Y_validation_batch = validation_data.get_input_tensors()
					validation_summary = sess.run(validation_summary_op, feed_dict={X:X_validation_batch, Y:Y_validation_batch, phase_train:False})
					test_writer.add_summary(validation_summary, step)


				step += 1

				print ("End = {}".format(time.time() - start))

def main():
	fire.Fire(Trainer)


if __name__ == '__main__':
	main()
