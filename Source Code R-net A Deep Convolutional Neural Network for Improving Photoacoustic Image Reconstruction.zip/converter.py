import os
import glob
import fire
import numpy as np
import scipy.io as sio
import h5py

from PIL import Image

def read_image(file_name):
	return np.asarray(Image.open(file_name).convert("L"),dtype='float32')

class Converter():
	def __init__(self, folder_path):
		self.files = glob.glob(os.path.join(folder_path, "*"))
	def mattonpy(self):
		for pth in self.files:
			try:
				mat_contents = sio.loadmat(pth)
			except Exception, e:
				hdf5_contents = h5py.File(pth)
				mat_contents = dict()
				mat_contents['x1'] = np.array(hdf5_contents['lancttls'])	
			np.save(open(pth, "w"), (mat_contents['x1']))
			
	def imagetonpy(self):
		for pth in self.files:
			img = read_image(pth)
			np.save(open(pth, "w"), img)

	def npytoimg(self):
		for pth in self.files:
			img = np.load(pth)
			print img
			Image.fromarray(img.astype(np.uint8)).save(pth)

	def npytomat(self):
		for pth in self.files:
			img = np.load(pth)
			sio.savemat(open(pth, 'w'), {'x':img})


def main():
	fire.Fire(Converter)

if __name__ == '__main__':
	main()