import fire
import numpy as np
import tensorflow as tf
import numpy as np
import data
import time
import timeit
import os
import shutil
import time
import glob
import  skimage.measure as measure
import matplotlib.pyplot as plt


from PIL import Image, ImageOps
from skimage.util import view_as_windows
from model import model
from tqdm import tqdm

def read_image(file_name, from_npy=False):
	if from_npy:
		return np.load(file_name)
	return np.asarray(Image.open(file_name).convert("L"),dtype='float32')


def read_multi_sensor_image(prefix_path, sensor_points, noise_level, img_name, from_npy=False):
    sensor_points = sorted(sensor_points)
    return read_image(os.path.join(prefix_path, str(sensor_points[0]), noise_level, 'backtranspose', img_name), from_npy)


def duplicate_axis(img):
	img = np.concatenate([img[..., np.newaxis], img[..., np.newaxis], img[..., np.newaxis]], axis = 2)
	return img[np.newaxis, ...]

def pad_image(img, stride_x, stride_y):
	n_row, n_col = img.shape
	if n_col % stride_x != 0:
		zero_buffer = np.zeros((n_row, (stride_x - n_col%stride_x)))
		img = np.concatenate((img, zero_buffer), axis = 1)
		n_row, n_col = img.shape
	if n_row %stride_y != 0:
		zero_buffer = np.zeros((stride_y - (n_row % stride_y), n_col))
		img = np.concatenate((img, zero_buffer), axis = 0)
	return img


def normalize_array(img):
	max_val = np.max(img.flatten())
	min_val = np.min(img.flatten())
	return ((img - min_val) / (max_val - min_val)) * 255.0

def imComplement(img):
	return 255.0 - img

# x_img = x_ttls;
# imgmax = max(x_img(:));
# imgmin = min(x_img(:));
# nse = std(x_img(:));
# snr = 20*log((imgmax-imgmin)/nse)



def snr_metric(x):
	x = x.flatten()
	img_max = np.max(x)
	img_min = np.min(x)
	x = (x - img_max) / (img_max - img_min)
	nse = np.std(x)
	return 20.0 * np.log((img_max - img_min) / nse)

def  cnr_metric (gnd, pred):
	non_zero_gnd = gnd != 0
	zero_gnd = gnd == 0
	a_roi = 1 / (201 * 201)
	a_back = 1 - a_roi
	mean_roi = np.mean(pred[non_zero_gnd])
	var_roi = np.var(pred[non_zero_gnd])
	mean_back = np.mean(pred[zero_gnd])
	var_back = np.var(pred[zero_gnd])
	cnr = (mean_roi - mean_back) / (np.sqrt(a_roi * var_roi + a_back * var_back))
	return cnr

def save_image(path, arr):

	import matplotlib
	from matplotlib import ticker

	fig = plt.figure(figsize = (3, 3)) # Your image (W)idth and (H)eight in inches
	ticks=[0, 0.25, 0.5, 0.75, 1]
	if np.max(arr.flatten() > 1): arr = arr / 255.0
	if np.max(arr.flatten() < 0): ticks = [np.min(arr.flatten()), -0.25, 0, 0.25, 0.5]
	im = plt.imshow(arr, cmap='gray') # Show the image
	cb = plt.colorbar(im,fraction=0.046, pad=0.04)
	tick_locator = ticker.MaxNLocator(nbins=5)
	cb.locator = tick_locator
	cb.ax.yaxis.set_major_locator(matplotlib.ticker.AutoLocator())
	cb.update_ticks()
	plt.axis('off')
	plt.savefig(path, bbox_inches='tight', format='eps')
	plt.close()


class  PSNR(object):
	"""
	Compute PSNR of a reconstructed image. The image reconstruction is done patchwise by using sliding windows.
	"""
	"""
	python patchwise/combine_patches.py --model-path=checkpoint_grd_mat/fcn-net-26700 psnr  --rec_image_prefix=Results/sample_images/ --seg_image_prefix=Results/sample_images/segmented/ --save_path=./Results/sample_images --save_extension=.jpg --invert=True

	python patchwise/combine_patches.py --model-path=checkpoint_grd_mat/fcn-net-26700  psnr_fast  --rec_image_prefix=Results/Generate/ --seg_image_prefix=Results/sample_images/segmented/ --save_path=./Results/Generate/ --noise-level=20 --save_extension=.eps --invert=True
	"""

	def __init__(self, model_path):
		self.model_path = model_path


	def psnr(self, rec_image_prefix, seg_image_prefix, save_path=None, save_extension = ".bmp", randomize=False, invert=False):
		import os
		from random import shuffle
		#Tensorflow needs these environmental variables to be set.
		os.environ["CUDA_DEVICE_ORDER"]="PCI_BUS_ID"   # see issue #152
		os.environ["CUDA_VISIBLE_DEVICES"]=""

		rec_images = [os.path.basename(x) for x in glob.glob(seg_image_prefix + "/*.bmp")]
		if randomize:
			shuffle(rec_images)
		img_height, img_width, batch_size, stride = 96, 96, 32, 20
		with tf.Session() as sess:
			sensor_points = [120]
			X = tf.placeholder(tf.float32, [None, img_height, img_width, len(sensor_points)])
			Y = tf.placeholder(tf.float32, [None, img_height, img_width, len(sensor_points)])
			phase_train = tf.placeholder(tf.bool, [], name='is_training')

			cnn = model(sess, optimizer=None, batch_size = batch_size, tot_res_blocks=8)
			prediction = cnn.inference(X, phase_train)

			model_saver = tf.train.Saver()
			model_saver.restore(sess, self.model_path)
			
			for image_name in rec_images:
				image_path = os.path.join(rec_image_prefix, image_name)
				rec_image = read_multi_sensor_image(rec_image_prefix, sensor_points, image_name, True)
				seg_image = read_image(os.path.join(seg_image_prefix, os.path.basename(image_path)), True)
				if invert:
					seg_image = np.asarray(ImageOps.invert(Image.fromarray(seg_image.astype(np.uint8))), dtype='float32')

				rec_image = pad_image(rec_image, stride, stride)
				n_row, n_col = rec_image.shape
				IReconstructed = np.zeros_like(rec_image)
				count_array = np.ones_like(rec_image)
				for i in tqdm(xrange(0, n_row - img_height, stride)):
					for j in tqdm(xrange(0, n_col - img_width, stride)):
						pred_i_j = sess.run(prediction,
							feed_dict={X:rec_image[i:i+img_height, j:j+img_width][np.newaxis, ..., np.newaxis]
							,phase_train:False})
						pred_i_j = np.squeeze(pred_i_j)
						IReconstructed[i:i+img_height, j:j+img_width] += pred_i_j
						count_array[i:i+img_height, j:j+img_width] += 1
				IReconstructed = IReconstructed / count_array
				IReconstructed = normalize_array(IReconstructed)
				IReconstructed = IReconstructed[0:201, 0:201]
				IReconstructed = IReconstructed.astype(np.float32)
				IReconstructed = imComplement(IReconstructed)
				print ( "Image = {}".format(os.path.basename(image_path)), measure.compare_psnr(im_true=seg_image, im_test=IReconstructed, dynamic_range=255.0))
				if save_path is not None:
					Image.fromarray(IReconstructed.astype(np.uint8)).save(
					  os.path.join(save_path, "recon_"+
					    os.path.basename(image_path.replace(".bmp", save_extension)))
					  )
					Image.fromarray(seg_image.astype(np.uint8)).save(
					  os.path.join(save_path, "seg_"+
					    os.path.basename(image_path.replace(".bmp", save_extension)))
					  )
					Image.fromarray(rec_image.astype(np.uint8)).save(
					  os.path.join(save_path, "back_"+
					    os.path.basename(image_path.replace(".bmp", save_extension)))
					  )

	def psnr_fast(self, rec_image_prefix, seg_image_prefix, save_path=None, save_extension = ".bmp", noise_level = 40, randomize=False, invert=False):
		import os
		from random import shuffle
		#Tensorflow needs these environmental variables to be set.
		os.environ["CUDA_DEVICE_ORDER"]="PCI_BUS_ID"   # see issue #152
		os.environ["CUDA_VISIBLE_DEVICES"]=""
		noise_level = str(noise_level)
		sensor_points = [120]
		save_path = os.path.join(save_path, str(sensor_points[0]), noise_level, 'reconstruction')

		rec_images = [os.path.basename(x) for x in glob.glob(seg_image_prefix + "/*.bmp")]
		if randomize:
			shuffle(rec_images)
		img_height, img_width, batch_size, stride = 96, 96, 32, 20
		with tf.Session() as sess:
			X = tf.placeholder(tf.float32, [None, img_height, img_width, len(sensor_points)])
			Y = tf.placeholder(tf.float32, [None, img_height, img_width, len(sensor_points)])
			phase_train = tf.placeholder(tf.bool, [], name='is_training')

			cnn = model(sess, optimizer=None, batch_size = batch_size, tot_res_blocks=8)
			prediction = cnn.inference(X, phase_train)

			model_saver = tf.train.Saver()
			model_saver.restore(sess, self.model_path)
			
			for image_name in rec_images:
				start = time.time()
				image_path = os.path.join(rec_image_prefix, image_name)
				rec_image = read_multi_sensor_image(rec_image_prefix, sensor_points, noise_level, image_name, True)
				seg_image = read_image(os.path.join(seg_image_prefix, os.path.basename(image_path)), True)
				if invert:
					seg_image = np.asarray(ImageOps.invert(Image.fromarray(seg_image.astype(np.uint8))), dtype='float32')

				rec_image = pad_image(rec_image, stride, stride)
				n_row, n_col = rec_image.shape
				IReconstructed = np.zeros_like(rec_image)
				count_array = np.ones_like(rec_image)

				batch_rec_image = np.zeros_like((batch_size, img_height, img_width, 1))
				rec_image_as_windows, pred_image_as_windows = [], []
				for i in tqdm(xrange(0, n_row - img_height, stride)):
					for j in tqdm(xrange(0, n_col - img_width, stride)):
						rec_image_as_windows.append(rec_image[i:i+img_height, j:j+img_width][..., np.newaxis])
				rec_image_as_windows = np.array(rec_image_as_windows)
				pred_image_as_windows = sess.run(prediction,
							feed_dict={X:rec_image_as_windows
							,phase_train:False})
				k = 0
				for i in tqdm(xrange(0, n_row - img_height, stride)):
					for j in tqdm(xrange(0, n_col - img_width, stride)):
						pred_i_j = pred_image_as_windows[k, ...]
						pred_i_j = np.squeeze(pred_i_j)
						IReconstructed[i:i+img_height, j:j+img_width] += pred_i_j
						count_array[i:i+img_height, j:j+img_width] += 1
						k += 1
				diff = time.time() - start
				print ("Diff = {}".format(diff))
				IReconstructed = IReconstructed / count_array
				IReconstructed = normalize_array(IReconstructed)
				IReconstructed = IReconstructed[0:201, 0:201]
				IReconstructed = IReconstructed.astype(np.float32)
				IReconstructed = imComplement(IReconstructed)


				psnr = measure.compare_psnr(im_true=seg_image, im_test=IReconstructed, dynamic_range=255.0)
				pc = np.corrcoef(seg_image.flatten(), IReconstructed.flatten())[0, 1]
				snr = snr_metric(IReconstructed.flatten())
				cnr = cnr_metric(seg_image.flatten(), IReconstructed.flatten())
				print ("Image {}".format(os.path.basename(image_path)))
				print ("PSNR = {}, PC = {}, SNR = {}, CNR = {}".format(psnr, pc, snr, cnr))
				print 


				if save_path is not None:
					save_image(os.path.join(save_path, "recon_" 
						+ os.path.basename(image_path.replace(".bmp", save_extension))),
					IReconstructed)
					save_image(os.path.join(save_path, "seg_" 
						+ os.path.basename(image_path.replace(".bmp", save_extension))),
					seg_image)
					save_image(os.path.join(save_path, "back_" 
						+ os.path.basename(image_path.replace(".bmp", save_extension))),
					(rec_image[:201, :201]))
			
			


def main():
	fire.Fire(PSNR)


if __name__ == '__main__':
	main()

