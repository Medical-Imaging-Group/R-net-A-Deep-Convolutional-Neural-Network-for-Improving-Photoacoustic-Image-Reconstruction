import os
import glob
import tensorflow as tf
import scipy.misc
import numpy as np
import random

from tqdm import tqdm
from itertools import product
from PIL import Image

np.random.seed(200)
def read_image(file_name, from_npy=False):
    if from_npy:
        return np.load(file_name)
    return np.asarray(Image.open(file_name).convert("L"),dtype='float32')

def read_multi_sensor_image(prefix_path, sensor_points, img_name):
    sensor_points = sorted(sensor_points)
    return read_image(os.path.join(prefix_path, str(sensor_points[0]), 'backtranspose', img_name), True)

def read_image_from_mat(file_name):
    mat_contents = sio.loadmat(file_name)
    return mat_contents['x1']


class Dataset():
    """docstring for DenoiseDataset"""
    def __init__(self, rec_image_path, seg_image_path, sensor_points, batch_size = 32, image_size=(201, 201)):
        self.batch_size = batch_size
        self.image_size = image_size
        self.rec_image_path = rec_image_path
        self.seg_image_path = seg_image_path
        self.sensor_points = sensor_points
        images = glob.glob(seg_image_path + "/*.bmp")
        self.imageNames = [os.path.basename(x) for x in images]


    def get_input_tensors(self):
        num_images = len(self.imageNames)
        sample = np.random.choice(xrange(num_images), self.batch_size)
        rec_batch = np.zeros((self.batch_size, self.image_size[0], self.image_size[1]))
        seg_batch = np.zeros((self.batch_size, self.image_size[0], self.image_size[1]))
    
        for i in xrange(self.batch_size):
            seg_image = read_image(os.path.join(self.seg_image_path, self.imageNames[sample[i]]), True) / 255.0 # Intrepreted as a probability map
            seg_batch[i, :, :] = seg_image
            rec_batch[i, :, :] = read_multi_sensor_image(self.rec_image_path, self.sensor_points, self.imageNames[sample[i]])
        return rec_batch[..., np.newaxis], seg_batch[..., np.newaxis]